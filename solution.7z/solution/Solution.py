from PyQt5 import QtCore, QtMultimedia
from PyQt5.QtWidgets import QApplication, QMainWindow
import sys
from PyQt5 import uic
from PyQt5.QtCore import Qt

class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('untitled.ui', self)


        self.pushButton.clicked.connect(self.play_do)
        self.pushButton_2.clicked.connect(self.play_re)
        self.pushButton_3.clicked.connect(self.play_mi)
        self.pushButton_4.clicked.connect(self.play_fa)
        self.pushButton_5.clicked.connect(self.play_sol)
        self.pushButton_6.clicked.connect(self.play_lja)
        self.pushButton_7.clicked.connect(self.play_si)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_1:
            self.play_do()
        elif event.key() == Qt.Key_2:
            self.play_re()
        elif event.key() == Qt.Key_3:
            self.play_mi()
        elif event.key() == Qt.Key_4:
            self.play_fa()
        elif event.key() == Qt.Key_5:
            self.play_sol()
        elif event.key() == Qt.Key_6:
            self.play_lja()
        elif event.key() == Qt.Key_7:
            self.play_si()

    def play_do(self):
        media = QtCore.QUrl.fromLocalFile("C:\\Users\\student\\Desktop\\Rosseev Ilia\\solution\\do.mp3")
        content = QtMultimedia.QMediaContent(media)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(content)
        self.player.play()

    def play_re(self):
        media = QtCore.QUrl.fromLocalFile("C:\\Users\\student\\Desktop\\Rosseev Ilia\\solution\\re.mp3")
        content = QtMultimedia.QMediaContent(media)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(content)
        self.player.play()

    def play_mi(self):
        media = QtCore.QUrl.fromLocalFile("C:\\Users\\student\\Desktop\\Rosseev Ilia\\solution\\mi.mp3")
        content = QtMultimedia.QMediaContent(media)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(content)
        self.player.play()

    def play_fa(self):
        media = QtCore.QUrl.fromLocalFile("C:\\Users\\student\\Desktop\\Rosseev Ilia\\solution\\fa.mp3")
        content = QtMultimedia.QMediaContent(media)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(content)
        self.player.play()

    def play_sol(self):
        media = QtCore.QUrl.fromLocalFile("C:\\Users\\student\\Desktop\\Rosseev Ilia\\solution\\sol.mp3")
        content = QtMultimedia.QMediaContent(media)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(content)
        self.player.play()

    def play_lja(self):
        media = QtCore.QUrl.fromLocalFile("C:\\Users\\student\\Desktop\\Rosseev Ilia\\solution\\lja.mp3")
        content = QtMultimedia.QMediaContent(media)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(content)
        self.player.play()

    def play_si(self):
        media = QtCore.QUrl.fromLocalFile("C:\\Users\\student\\Desktop\\Rosseev Ilia\\solution\\si.mp3")
        content = QtMultimedia.QMediaContent(media)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(content)
        self.player.play()


app = QApplication(sys.argv)
ex = MyWidget()
ex.show()
sys.exit(app.exec_())
